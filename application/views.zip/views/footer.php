<style>
    .scrollto{
        color: white !important;
    }
</style>
<!-- ======= Footer ======= -->
<section class="space" style="background-color: black; color: white;">
    <div class="container">
        <div class="row pb-5">
            <div class="col-md-12 text-center">
                <a href="Main font" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"  style="height:5vh;" >
                    ENCOME</a>
            </div>
        </div>
        <div class="row pt-3 d-flex justify-content-around">
            <div class="col-md-6">
            <ul class="d-flex justify-content-between">
                <li><a class="nav-link scrollto active" href="Main">Home</a></li>
                <li><a class="nav-link scrollto" href="">Solutions</a></li>
                <li><a class="nav-link scrollto" href="">Cases</a></li>
                <li><a class="nav-link scrollto " href="">Blogs</a></li>
                <li><a class="nav-link scrollto" href="Career">Pricing</a></li>
                <li><a class="nav-link scrollto" href="">About</a></li>
                <li><a class="nav-link scrollto" href="">Contact</a></li>
              </ul>
            </div>
        </div>
    </div>

</section>






<!-- ======= Footer ======= -->


<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
        class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>